package com.sg.cardealership.dao;

import com.sg.cardealership.model.Cars;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
@Profile("database")
public class InventoryDBDao implements InventoryDao
{

}
