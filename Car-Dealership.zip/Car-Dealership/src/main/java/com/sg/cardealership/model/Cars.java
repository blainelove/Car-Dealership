package com.sg.cardealership.model;

import java.math.BigDecimal;
import java.util.Objects;

public class Cars
{
    private int carId;
    private boolean isNew;
    private boolean isFeatured;
    private boolean isSold;
    private int unitsInStock;
    private int mileage;
    private int modelYear;
    private String VIN;
    private int makeId;
    private int modelId;
    private String transmissionType;
    private String bodyStyleType;
    private String bodyColorType;
    private String intColorType;
    private BigDecimal salePrice;
    private BigDecimal msrp;
    private String vehicleDetails;



    public Cars()
    {
        this.carId = 0;
        this.isNew = false;
        this.isFeatured = false;
        this.isSold = false;
        this.unitsInStock = 0;
        this.mileage = 0;
        this.modelYear = 0;
        this.VIN = "";
        this.makeId = 0;
        this.modelId = 0;
        this.transmissionType = "";
        this.bodyStyleType = "";
        this.bodyColorType = "";
        this.intColorType = "";
        this.salePrice = BigDecimal.valueOf(0);
        this.msrp = BigDecimal.valueOf(0);
        this.vehicleDetails = "";
    }

        public Cars(int carId, boolean isNew, boolean isFeatured, boolean isSold, int unitsInStock, int mileage, int modelYear, String VIN, int makeId, int modelId, String transmissionType, String bodyStyleType, String bodyColorType, String intColorType, BigDecimal salePrice, BigDecimal msrp, String vehicleDetails) {
        this.carId = carId;
        this.isNew = isNew;
        this.isFeatured = isFeatured;
        this.isSold = isSold;
        this.unitsInStock = unitsInStock;
        this.mileage = mileage;
        this.modelYear = modelYear;
        this.VIN = VIN;
        this.makeId = makeId;
        this.modelId = modelId;
        this.transmissionType = transmissionType;
        this.bodyStyleType = bodyStyleType;
        this.bodyColorType = bodyColorType;
        this.intColorType = intColorType;
        this.salePrice = salePrice;
        this.msrp = msrp;
        this.vehicleDetails = vehicleDetails;
    }

    public int getCarId() {
        return carId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
    }

    public boolean isIsNew() {
        return isNew;
    }

    public void setIsNew(boolean isNew) {
        this.isNew = isNew;
    }

    public boolean isIsFeatured() {
        return isFeatured;
    }

    public void setIsFeatured(boolean isFeatured) {
        this.isFeatured = isFeatured;
    }

    public boolean isIsSold() {
        return isSold;
    }

    public void setIsSold(boolean isSold) {
        this.isSold = isSold;
    }

    public int getUnitsInStock() {
        return unitsInStock;
    }

    public void setUnitsInStock(int unitsInStock) {
        this.unitsInStock = unitsInStock;
    }

    public int getMileage() {
        return mileage;
    }

    public void setMileage(int mileage) {
        this.mileage = mileage;
    }

    public int getModelYear() {
        return modelYear;
    }

    public void setModelYear(int modelYear) {
        this.modelYear = modelYear;
    }

    public String getVIN() {
        return VIN;
    }

    public void setVIN(String VIN) {
        this.VIN = VIN;
    }

    public int getMakeId() {
        return makeId;
    }

    public void setMakeId(int makeId) {
        this.makeId = makeId;
    }

    public int getModelId() {
        return modelId;
    }

    public void setModelId(int modelId) {
        this.modelId = modelId;
    }

    public String getTransmissionType() {
        return transmissionType;
    }

    public void setTransmissionType(String transmissionType) {
        this.transmissionType = transmissionType;
    }

    public String getBodyStyleType() {
        return bodyStyleType;
    }

    public void setBodyStyleType(String bodyStyleType) {
        this.bodyStyleType = bodyStyleType;
    }

    public String getBodyColorType() {
        return bodyColorType;
    }

    public void setBodyColorType(String bodyColorType) {
        this.bodyColorType = bodyColorType;
    }

    public String getIntColorType() {
        return intColorType;
    }

    public void setIntColorType(String intColorType) {
        this.intColorType = intColorType;
    }

    public BigDecimal getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(BigDecimal salePrice) {
        this.salePrice = salePrice;
    }

    public BigDecimal getMsrp() {
        return msrp;
    }

    public void setMsrp(BigDecimal msrp) {
        this.msrp = msrp;
    }

    public String getVehicleDetails() {
        return vehicleDetails;
    }

    public void setVehicleDetails(String vehicleDetails) {
        this.vehicleDetails = vehicleDetails;
    }
        
        

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 19 * hash + this.carId;
        hash = 19 * hash + (this.isNew ? 1 : 0);
        hash = 19 * hash + (this.isFeatured ? 1 : 0);
        hash = 19 * hash + (this.isSold ? 1 : 0);
        hash = 19 * hash + this.unitsInStock;
        hash = 19 * hash + this.mileage;
        hash = 19 * hash + this.modelYear;
        hash = 19 * hash + Objects.hashCode(this.VIN);
        hash = 19 * hash + this.makeId;
        hash = 19 * hash + this.modelId;
        hash = 19 * hash + Objects.hashCode(this.transmissionType);
        hash = 19 * hash + Objects.hashCode(this.bodyStyleType);
        hash = 19 * hash + Objects.hashCode(this.bodyColorType);
        hash = 19 * hash + Objects.hashCode(this.intColorType);
        hash = 19 * hash + Objects.hashCode(this.salePrice);
        hash = 19 * hash + Objects.hashCode(this.msrp);
        hash = 19 * hash + Objects.hashCode(this.vehicleDetails);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cars other = (Cars) obj;
        if (this.carId != other.carId) {
            return false;
        }
        if (this.isNew != other.isNew) {
            return false;
        }
        if (this.isFeatured != other.isFeatured) {
            return false;
        }
        if (this.isSold != other.isSold) {
            return false;
        }
        if (this.unitsInStock != other.unitsInStock) {
            return false;
        }
        if (this.mileage != other.mileage) {
            return false;
        }
        if (this.modelYear != other.modelYear) {
            return false;
        }
        if (this.makeId != other.makeId) {
            return false;
        }
        if (this.modelId != other.modelId) {
            return false;
        }
        if (!Objects.equals(this.VIN, other.VIN)) {
            return false;
        }
        if (!Objects.equals(this.transmissionType, other.transmissionType)) {
            return false;
        }
        if (!Objects.equals(this.bodyStyleType, other.bodyStyleType)) {
            return false;
        }
        if (!Objects.equals(this.bodyColorType, other.bodyColorType)) {
            return false;
        }
        if (!Objects.equals(this.intColorType, other.intColorType)) {
            return false;
        }
        if (!Objects.equals(this.vehicleDetails, other.vehicleDetails)) {
            return false;
        }
        if (!Objects.equals(this.salePrice, other.salePrice)) {
            return false;
        }
        if (!Objects.equals(this.msrp, other.msrp)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Cars{" + "carId=" + carId + ", isNew=" + isNew + ", isFeatured=" + isFeatured + ", isSold=" + isSold + ", unitsInStock=" + unitsInStock + ", mileage=" + mileage + ", modelYear=" + modelYear + ", VIN=" + VIN + ", makeId=" + makeId + ", modelId=" + modelId + ", transmissionType=" + transmissionType + ", bodyStyleType=" + bodyStyleType + ", bodyColorType=" + bodyColorType + ", intColorType=" + intColorType + ", salePrice=" + salePrice + ", msrp=" + msrp + ", vehicleDetails=" + vehicleDetails + '}';
    }
}