package com.sg.cardealership.dao;

public interface AdminDao
{

}
